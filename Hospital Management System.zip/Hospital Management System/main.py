import tkinter as tk
from tkinter import messagebox

class Hospital:
    def __init__(self, id, name, address):
        self.id = id
        self.name = name
        self.address = address
        self.staff = []
        self.patients = []

    # Getter and setter methods for ID
    def get_id(self):
        return self.id

    def set_id(self, id):
        self.id = id

    # Getter and setter methods for name
    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    # Getter and setter methods for address
    def get_address(self):
        return self.address

    def set_address(self, address):
        self.address = address

    # Getter method for staff list
    def get_staff(self):
        return self.staff

    # Getter method for patient list
    def get_patients(self):
        return self.patients

    # Method to add staff to the hospital
    def add_staff(self, staff):
        self.staff.append(staff)

    # Method to remove staff from the hospital
    def remove_staff(self, staff):
        if staff in self.staff:
            self.staff.remove(staff)

    # Method to add patient to the hospital
    def add_patient(self, patient):
        self.patients.append(patient)

    # Method to remove patient from the hospital
    def remove_patient(self, patient):
        if patient in self.patients:
            self.patients.remove(patient)

class Staff:
    def __init__(self, id, name, address, hospital):
        self.id = id
        self.name = name
        self.address = address
        self.hospital = hospital  # This attribute holds the reference to the hospital

        # Add staff to the hospital's staff list
        self.hospital.add_staff(self)

    # Getter and setter methods for ID
    def get_id(self):
        return self.id

    def set_id(self, id):
        self.id = id

    # Getter and setter methods for name
    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    # Getter and setter methods for address
    def get_address(self):
        return self.address

    def set_address(self, address):
        self.address = address

class Doctor(Staff):
    def __init__(self, id, name, address, contact_info, office_number,hospital):
        super().__init__(id, name, address, hospital) 
        self.contact_info = contact_info
        self.office_number = office_number
        self.appointments = []

    # Getter and setter methods for contact info
    def get_contact_info(self):
        return self.contact_info

    def set_contact_info(self, contact_info):
        self.contact_info = contact_info

    # Getter and setter methods for office number
    def get_office_number(self):
        return self.office_number

    def set_office_number(self, office_number):
        self.office_number = office_number

    # Method to add an appointment
    def add_appointment(self, appointment):
        self.appointments.append(appointment)

    # Method to remove an appointment
    def remove_appointment(self, appointment):
        if appointment in self.appointments:
            self.appointments.remove(appointment)

    # Method to check appointments
    def check_appointments(self):
        if self.appointments:
            print("Appointments for Dr. {}: ".format(self.get_name()))
            for appointment in self.appointments:
                print("- ", appointment)
        else:
            print("No appointments scheduled for Dr. {}.".format(self.get_name()))

    def add_appointment(self, appointment):
        self.appointments.append(appointment)

class Nurse(Staff):
    def __init__(self, id, name, address, contact_info, ward_number,hospital):
        super().__init__(id, name, address, hospital) 
        self.contact_info = contact_info
        self.ward_number = ward_number

    # Getter and setter methods for contact info
    def get_contact_info(self):
        return self.contact_info

    def set_contact_info(self, contact_info):
        self.contact_info = contact_info

    # Getter and setter methods for ward number
    def get_ward_number(self):
        return self.ward_number

    def set_ward_number(self, ward_number):
        self.ward_number = ward_number

class Patient:
    def __init__(self, id, name, address, contact_info, prescribed_medications):
        self.id = id
        self.name = name
        self.address = address
        self.contact_info = contact_info
        self.prescribed_medications = prescribed_medications
        self.appointments = []

    # Getter and setter methods for ID
    def get_id(self):
        return self.id

    def set_id(self, id):
        self.id = id

    # Getter and setter methods for name
    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    # Getter and setter methods for address
    def get_address(self):
        return self.address

    def set_address(self, address):
        self.address = address

    # Getter and setter methods for contact info
    def get_contact_info(self):
        return self.contact_info

    def set_contact_info(self, contact_info):
        self.contact_info = contact_info

    # Getter and setter methods for prescribed medications
    def get_prescribed_medications(self):
        return self.prescribed_medications

    def set_prescribed_medications(self, prescribed_medications):
        self.prescribed_medications = prescribed_medications

    # Method to add an appointment
    def add_appointment(self, appointment):
        self.appointments.append(appointment)

    # Method to consult a doctor
    def consult_doctor(self, doctor):
        print("{} is consulting with Dr. {}".format(self.get_name(), doctor.get_name()))

    # Method to get appointments
    def get_appointments(self):
        if self.appointments:
            print("Appointments for {}:".format(self.get_name()))
            for appointment in self.appointments:
                print("- ", appointment)
        else:
            print("No appointments scheduled for {}.".format(self.get_name()))

class Appointment:
    def __init__(self, id, time, description):
        self.id = id
        self.time = time
        self.description = description

    # Getter and setter methods for ID
    def get_id(self):
        return self.id

    def set_id(self, id):
        self.id = id

    # Getter and setter methods for time
    def get_time(self):
        return self.time

    def set_time(self, time):
        self.time = time

    # Getter and setter methods for description
    def get_description(self):
        return self.description

    def set_description(self, description):
        self.description = description

class Medicine:
    def __init__(self, id, name, description):
        self.id = id
        self.name = name
        self.description = description

    # Getter and setter methods for ID
    def get_id(self):
        return self.id

    def set_id(self, id):
        self.id = id

    # Getter and setter methods for name
    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    # Getter and setter methods for description
    def get_description(self):
        return self.description

    def set_description(self, description):
        self.description = description

class FileManager:
    def __init__(self):
        pass

    def write_to_file(self, filename, data):
        with open(filename, 'a') as file:
            file.write(data + '\n')

    def read_from_file(self, filename):
        try:
            with open(filename, 'r') as file:
                data = file.readlines()
                return data
        except FileNotFoundError:
            return []

    def clear_file(self, filename):
        open(filename, 'w').close()
        
def read_passwords():
    # Reading passwords from passwords.txt and storing them in a dictionary
    passwords = {}
    with open("passwords.txt", "r") as file:
        for line in file:
            role, password = line.strip().split(",")
            passwords[role.strip()] = password.strip()
    return passwords

def update_username(*args):
    # This function Automatically fill username field based on selected role
    role = role_var.get()
    if role:
        username_entry.delete(0, tk.END)  # Clearing previous entry
        username_entry.insert(0, role)  # Storing username based on role
        
def login():
    try:
        username = username_entry.get()
        password = password_entry.get()
        role = role_var.get()

        # Authenticate user based on role and password
        passwords = read_passwords()

        if role in passwords and passwords[role] == password and username == role:
            messagebox.showinfo("Login Successful", f"Welcome, {role}!")
            # Opening respective dashboard based on role
            if role == "Administrator":
                admin_dashboard = AdministratorDashboard(root)
                root.withdraw()  # Hiding the login window
                admin_dashboard.mainloop()
            elif role == "Staff":
                staff_dashboard = StaffDashboard(root)
                root.withdraw()  # Hiding the login window
                staff_dashboard.mainloop()
            elif role == "Patient":
                patient_dashboard = PatientDashboard(root)
                root.withdraw()  # Hiding the login window
                patient_dashboard.mainloop()
        else:
            messagebox.showerror("Login Error", f"Invalid username or password for {role}.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

class AdministratorDashboard(tk.Toplevel):
    def __init__(self, root):
        try:
            super().__init__(root)
            self.title("Administrator Dashboard")
            self.configure(background="navy")  # Setting background color to navy

            # Setting window size and position
            window_width = 1000
            window_height = 400
            screen_width = root.winfo_screenwidth()  
            screen_height = root.winfo_screenheight() 
            x_coordinate = (screen_width - window_width) / 2
            y_coordinate = (screen_height - window_height) / 2
            self.geometry("%dx%d+%d+%d" % (window_width, window_height, x_coordinate, y_coordinate))

            # Dashboard frame
            dashboard_frame = tk.Frame(self, bg="navy")
            dashboard_frame.pack(fill=tk.BOTH)

            # Functionality display frame
            self.functionality_frame = tk.Frame(self, bg="navy", height=300)
            self.functionality_frame.pack(expand=True, fill=tk.BOTH)

            # Functionality display label
            self.functionality_label = tk.Label(self.functionality_frame, text="Select a functionality", bg="white")
            self.functionality_label.pack(expand=True, pady=20)

            # Add Doctor button
            self.add_doctor_button = tk.Button(dashboard_frame, text="Add Doctor", width=10, command=self.add_doctor)
            self.add_doctor_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Delete Doctor button
            self.delete_doctor_button = tk.Button(dashboard_frame, text="Delete Doctor", width=11, command=self.delete_doctor)
            self.delete_doctor_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Update Doctor button
            self.update_doctor_button = tk.Button(dashboard_frame, text="Update Doctor", width=12, command=self.update_doctor)
            self.update_doctor_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Add Nurse button
            self.add_nurse_button = tk.Button(dashboard_frame, text="Add Nurse", width=10, command=self.add_nurse)
            self.add_nurse_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Delete Nurse button
            self.delete_nurse_button = tk.Button(dashboard_frame, text="Delete Nurse", width=12, command=self.delete_nurse)
            self.delete_nurse_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Update Nurse button
            self.update_nurse_button = tk.Button(dashboard_frame, text="Update Nurse", width=12, command=self.update_nurse)
            self.update_nurse_button.pack(side=tk.LEFT, padx=12, pady=12)

            # View All Doctors button
            self.view_all_doctors_button = tk.Button(dashboard_frame, text="View All Doctors", width=13, command=self.view_all_doctors)
            self.view_all_doctors_button.pack(side=tk.LEFT, padx=12, pady=12)

            # View All Nurses button
            self.view_all_nurses_button = tk.Button(dashboard_frame, text="View All Nurses", width=13, command=self.view_all_nurses)
            self.view_all_nurses_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Logout button
            self.logout_button = tk.Button(dashboard_frame, text="Logout", width=13, command=self.show_login_window)
            self.logout_button.pack(side=tk.LEFT, padx=12, pady=12)

            self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.doctor_details_frame.pack(expand=True)

            self.nurse_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.nurse_details_frame.pack(expand=True)

            # Binding the closing event to show login window
            self.protocol("WM_DELETE_WINDOW", self.show_login_window)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def show_login_window(self):
        try:
            # Destroy administrator dashboard window
            self.destroy()
            password_entry.delete(0,tk.END)

            # Recreate login window
            root.deiconify()  # Restore visibility of the login window
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def view_all_doctors(self):
        try:
            self.functionality_label.destroy()

            # Destroy nurse details frame if it exists
            if hasattr(self, 'nurse_details_frame'):
                self.nurse_details_frame.destroy()

            # Destroy doctor details frame if it exists
            if hasattr(self, 'doctor_details_frame'):
                self.doctor_details_frame.destroy()
            
            if hasattr(self,'nurse_update_frame'):
                self.nurse_update_frame.destroy()
            
            if hasattr(self,'doctor_update_frame'):
                self.doctor_update_frame.destroy()

            # Recreating doctor details frame
            self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.doctor_details_frame.pack(expand=True)

            # Heading label
            heading_label = tk.Label(self.doctor_details_frame, text="All Doctors", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
            heading_label.grid(row=0, columnspan=2, pady=(10, 5))

            # Creating a scrollable canvas
            canvas = tk.Canvas(self.doctor_details_frame, bg="white")
            canvas.grid(row=1, column=0, sticky="nsew")

            # Adding a vertical scrollbar
            scrollbar = tk.Scrollbar(self.doctor_details_frame, orient="vertical", command=canvas.yview)
            scrollbar.grid(row=1, column=1, sticky="ns")
            canvas.configure(yscrollcommand=scrollbar.set)

            # Frame for doctor labels
            doctor_frame = tk.Frame(canvas, bg="white")
            canvas.create_window((0, 0), window=doctor_frame, anchor="nw")

            # Reading and displaying all doctors from doctor.txt
            with open("doctor.txt", "r") as file:
                doctors = file.readlines()
                for index, doctor in enumerate(doctors, start=1):
                    doctor_data = doctor.strip().split(",")
                    # Extracting doctor details
                    doctor_id = doctor_data[0].strip()
                    doctor_name = doctor_data[1].strip()
                    doctor_contact = doctor_data[4].strip()
                    doctor_label_text = "ID: " + str(doctor_id) + ", Name: " + str(doctor_name) + ", Contact: " + str(doctor_contact)
                    doctor_label = tk.Label(doctor_frame, text=doctor_label_text, bg="white", fg="black", font=("Helvetica", 10))
                    doctor_label.grid(row=index, columnspan=5, pady=5)

            # Updating scroll region
            doctor_frame.update_idletasks()
            canvas.config(scrollregion=canvas.bbox("all"))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def view_all_nurses(self):
        try:
            self.functionality_label.destroy()

            # Destroy doctor details frame if it exists
            if hasattr(self, 'doctor_details_frame'):
                self.doctor_details_frame.destroy()

            # Destroy nurse details frame if it exists
            if hasattr(self, 'nurse_details_frame'):
                self.nurse_details_frame.destroy()
            
            if hasattr(self,'doctor_update_frame'):
                self.doctor_update_frame.destroy()
            
            if hasattr(self,'nurse_update_frame'):
                self.nurse_update_frame.destroy()

            # Recreating nurse details frame
            self.nurse_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.nurse_details_frame.pack(expand=True)

            # Heading label
            heading_label = tk.Label(self.nurse_details_frame, text="All Nurses", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
            heading_label.grid(row=0, columnspan=2, pady=(10, 5))

            # Creating a scrollable canvas
            canvas = tk.Canvas(self.nurse_details_frame, bg="white")
            canvas.grid(row=1, column=0, sticky="nsew")

            # Adding a vertical scrollbar
            scrollbar = tk.Scrollbar(self.nurse_details_frame, orient="vertical", command=canvas.yview)
            scrollbar.grid(row=1, column=1, sticky="ns")
            canvas.configure(yscrollcommand=scrollbar.set)

            # Frame for nurse labels
            nurse_frame = tk.Frame(canvas, bg="white")
            canvas.create_window((0, 0), window=nurse_frame, anchor="nw")

            # Reading and displaying all nurses from nurse.txt
            with open("nurse.txt", "r") as file:
                nurses = file.readlines()
                for index, nurse in enumerate(nurses, start=1):
                    nurse_data = nurse.strip().split(",")
                    # Extracting nurse details
                    nurse_id = nurse_data[0].strip()
                    nurse_name = nurse_data[1].strip()
                    nurse_contact = nurse_data[3].strip()
                    nurse_label_text = "ID: " + str(nurse_id) + ", Name: " + str(nurse_name) + ", Contact: " + str(nurse_contact)
                    nurse_label = tk.Label(nurse_frame, text=nurse_label_text, bg="white", fg="black", font=("Helvetica", 10))
                    nurse_label.grid(row=index, columnspan=5, pady=5)

            # Updating scroll region
            nurse_frame.update_idletasks()
            canvas.config(scrollregion=canvas.bbox("all"))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")


    def add_doctor(self):

        self.functionality_label.destroy()

        # Destroy nurse details frame if it exists
        if hasattr(self, 'nurse_details_frame'):
            self.nurse_details_frame.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()
        
        if hasattr(self,'nurse_update_frame'):
            self.nurse_update_frame.destroy()
        
        if hasattr(self,'doctor_update_frame'):
            self.doctor_update_frame.destroy()

        # Recreating doctor details frame
        self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.doctor_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.doctor_details_frame, text="Enter Doctor Details", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Doctor details labels and entry fields
        id_label = tk.Label(self.doctor_details_frame, text="Doctor ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.doctor_id_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor ID entry
        self.doctor_id_entry.grid(row=1, column=1, padx=10, pady=5)

        name_label = tk.Label(self.doctor_details_frame, text="Doctor Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        name_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
        self.doctor_name_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor name entry
        self.doctor_name_entry.grid(row=2, column=1, padx=10, pady=5)

        address_label = tk.Label(self.doctor_details_frame, text="Doctor Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        address_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
        self.doctor_address_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor address entry
        self.doctor_address_entry.grid(row=3, column=1, padx=10, pady=5)

        contact_label = tk.Label(self.doctor_details_frame, text="Contact Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        contact_label.grid(row=4, column=0, sticky="e", padx=10, pady=5)
        self.doctor_contact_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor contact entry
        self.doctor_contact_entry.grid(row=4, column=1, padx=10, pady=5)

        office_label = tk.Label(self.doctor_details_frame, text="Office Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        office_label.grid(row=5, column=0, sticky="e", padx=10, pady=5)
        self.doctor_office_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor office entry
        self.doctor_office_entry.grid(row=5, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.doctor_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_doctor)
        submit_button.grid(row=6, columnspan=2, padx=10, pady=(10, 20))

    def submit_doctor(self):
        # Getting doctor details from entry fields
        doctor_id = self.doctor_id_entry.get()
        name = self.doctor_name_entry.get()
        address = self.doctor_address_entry.get()
        office_number = self.doctor_office_entry.get()
        contact_number = self.doctor_contact_entry.get()

        # Validating if any field is empty
        if not all([doctor_id, name, address, office_number, contact_number]):
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        # Saving doctor details to a doctor.txt
        with open("doctor.txt", "a") as f:
            f.write(f"{doctor_id},{name},{address},{office_number},{contact_number}\n")

        # Inform user about successful addition
        messagebox.showinfo("Success", "Doctor added successfully.")

        # Clear entry fields
        self.clear_doctor_fields()

    def clear_doctor_fields(self):
        if hasattr(self, 'doctor_id_entry'):
            self.doctor_id_entry.delete(0, tk.END)
        if hasattr(self, 'doctor_name_entry'):
            self.doctor_name_entry.delete(0, tk.END)
        if hasattr(self, 'doctor_address_entry'):
            self.doctor_address_entry.delete(0, tk.END)
        if hasattr(self, 'doctor_contact_entry'):
            self.doctor_contact_entry.delete(0, tk.END)
        if hasattr(self, 'doctor_office_entry'):
            self.doctor_office_entry.delete(0, tk.END)

    def add_nurse(self):
        self.functionality_label.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        # Destroy nurse details frame if it exists
        if hasattr(self, 'nurse_details_frame'):
            self.nurse_details_frame.destroy()

        if hasattr(self,'nurse_update_frame'):
            self.nurse_update_frame.destroy()
        
        if hasattr(self,'doctor_update_frame'):
            self.doctor_update_frame.destroy()

        # Recreating nurse details frame
        self.nurse_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.nurse_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.nurse_details_frame, text="Enter Nurse Details", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Nurse details labels and entry fields
        id_label = tk.Label(self.nurse_details_frame, text="Nurse ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.nurse_id_entry = tk.Entry(self.nurse_details_frame)  # Using separate attribute for nurse ID entry
        self.nurse_id_entry.grid(row=1, column=1, padx=10, pady=5)

        name_label = tk.Label(self.nurse_details_frame, text="Nurse Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        name_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
        self.nurse_name_entry = tk.Entry(self.nurse_details_frame)  # Using separate attribute for nurse name entry
        self.nurse_name_entry.grid(row=2, column=1, padx=10, pady=5)

        address_label = tk.Label(self.nurse_details_frame, text="Nurse Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        address_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
        self.nurse_address_entry = tk.Entry(self.nurse_details_frame)  # Using separate attribute for nurse address entry
        self.nurse_address_entry.grid(row=3, column=1, padx=10, pady=5)

        contact_label = tk.Label(self.nurse_details_frame, text="Contact Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        contact_label.grid(row=4, column=0, sticky="e", padx=10, pady=5)
        self.nurse_contact_entry = tk.Entry(self.nurse_details_frame)  # Using separate attribute for nurse contact entry
        self.nurse_contact_entry.grid(row=4, column=1, padx=10, pady=5)

        ward_label = tk.Label(self.nurse_details_frame, text="Ward Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        ward_label.grid(row=5, column=0, sticky="e", padx=10, pady=5)
        self.nurse_ward_entry = tk.Entry(self.nurse_details_frame)  # Entry for ward number
        self.nurse_ward_entry.grid(row=5, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.nurse_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_nurse)
        submit_button.grid(row=6, columnspan=2, padx=10, pady=(10, 20))

    def submit_nurse(self):
        # Getting nurse details from entry fields
        nurse_id = self.nurse_id_entry.get()
        name = self.nurse_name_entry.get()
        address = self.nurse_address_entry.get()
        contact_number = self.nurse_contact_entry.get()
        ward_number = self.nurse_ward_entry.get()  # Getting ward number

        # Validating if any field is empty
        if not all([nurse_id, name, address, contact_number, ward_number]):
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        # Saving nurse details to a nurse.txt
        with open("nurse.txt", "a") as f:
            f.write(f"{nurse_id},{name},{address},{contact_number},{ward_number}\n")

        # Inform user about successful addition
        messagebox.showinfo("Success", "Nurse added successfully.")

        # Clearing entry fields
        self.clear_nurse_fields()

    def clear_nurse_fields(self):
        if hasattr(self, 'nurse_id_entry'):
            self.nurse_id_entry.delete(0, tk.END)
        if hasattr(self, 'nurse_name_entry'):
            self.nurse_name_entry.delete(0, tk.END)
        if hasattr(self, 'nurse_address_entry'):
            self.nurse_address_entry.delete(0, tk.END)
        if hasattr(self, 'nurse_contact_entry'):
            self.nurse_contact_entry.delete(0, tk.END)
        if hasattr(self, 'nurse_ward_entry'):
            self.nurse_ward_entry.delete(0, tk.END)

    def delete_doctor(self):
        self.functionality_label.destroy()

        # Destroy nurse details frame if it exists
        if hasattr(self, 'nurse_details_frame'):
            self.nurse_details_frame.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        if hasattr(self,'nurse_update_frame'):
            self.nurse_update_frame.destroy()
        
        if hasattr(self,'doctor_update_frame'):
            self.doctor_update_frame.destroy()

        # Recreating doctor details frame
        self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.doctor_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.doctor_details_frame, text="Delete Doctor", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Doctor ID label and entry field
        id_label = tk.Label(self.doctor_details_frame, text="Doctor ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.doctor_id_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor ID entry
        self.doctor_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.doctor_details_frame, text="Delete", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_delete_doctor)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_delete_doctor(self):
        # Getting doctor ID from entry field
        doctor_id = self.doctor_id_entry.get()

        # Validating if the doctor ID is provided
        if not doctor_id:
            messagebox.showerror("Error", "Please enter Doctor ID.")
            return

        # Searching the doctor in the file
        with open("doctor.txt", "r") as f:
            lines = f.readlines()

        found = False
        with open("doctor.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract doctor ID
                current_doctor_id, *details = line.strip().split(",")
                if current_doctor_id != doctor_id:
                    # writing the doctor details back to the file if ID doesn't match
                    f.write(line)
                else:
                    found = True

        if found:
            messagebox.showinfo("Success", "Doctor deleted successfully.")
            self.clear_delete_doctor_fields()
        else:
            messagebox.showerror("Error", "Doctor ID not found.")

    def clear_delete_doctor_fields(self):
        if hasattr(self, 'doctor_id_entry'):
            self.doctor_id_entry.delete(0, tk.END)

    def delete_nurse(self):
        self.functionality_label.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        # Destroy nurse details frame if it exists
        if hasattr(self, 'nurse_details_frame'):
            self.nurse_details_frame.destroy()

        if hasattr(self,'nurse_update_frame'):
            self.nurse_update_frame.destroy()
        
        if hasattr(self,'doctor_update_frame'):
            self.doctor_update_frame.destroy()

        # Recreating nurse details frame
        self.nurse_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.nurse_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.nurse_details_frame, text="Delete Nurse", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Nurse ID label and entry field
        id_label = tk.Label(self.nurse_details_frame, text="Nurse ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.nurse_id_entry = tk.Entry(self.nurse_details_frame)  # Using separate attribute for nurse ID entry
        self.nurse_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.nurse_details_frame, text="Delete", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_delete_nurse)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_delete_nurse(self):
        # Getting nurse ID from entry field
        nurse_id = self.nurse_id_entry.get()

        # Validating if the nurse ID is provided
        if not nurse_id:
            messagebox.showerror("Error", "Please enter Nurse ID.")
            return

        # Searching for the nurse in the file
        with open("nurse.txt", "r") as f:
            lines = f.readlines()

        found = False
        with open("nurse.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract nurse ID
                current_nurse_id, *details = line.strip().split(",")
                if current_nurse_id != nurse_id:
                    # writing the nurse details back to the file if ID doesn't match
                    f.write(line)
                else:
                    found = True

        if found:
            messagebox.showinfo("Success", "Nurse deleted successfully.")
            self.clear_delete_nurse_fields()
        else:
            messagebox.showerror("Error", "Nurse ID not found.")

    def clear_delete_nurse_fields(self):
        if hasattr(self, 'nurse_id_entry'):
            self.nurse_id_entry.delete(0, tk.END)

    def update_doctor(self):
        self.functionality_label.destroy()

        # Destroy nurse details frame if it exists
        if hasattr(self, 'nurse_details_frame'):
            self.nurse_details_frame.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        if hasattr(self,'nurse_update_frame'):
            self.nurse_update_frame.destroy()
        
        if hasattr(self,'doctor_update_frame'):
            self.doctor_update_frame.destroy()

        # Recreating doctor details frame
        self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.doctor_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.doctor_details_frame, text="Update Doctor", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Doctor ID label and entry field
        id_label = tk.Label(self.doctor_details_frame, text="Doctor ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.doctor_id_entry = tk.Entry(self.doctor_details_frame)  # Using separate attribute for doctor ID entry
        self.doctor_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.doctor_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_update_doctor)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_update_doctor(self):
        # Getting doctor ID from entry field
        doctor_id = self.doctor_id_entry.get()

        # Validating if the doctor ID is provided
        if not doctor_id:
            messagebox.showerror("Error", "Please enter Doctor ID.")
            return

        # Searching the doctor in the file
        with open("doctor.txt", "r") as f:
            lines = f.readlines()

        found = False
        for line in lines:
            # Splitting the line to extract doctor ID and details
            current_doctor_id, name, address, office_number, contact_number = line.strip().split(",")
            if current_doctor_id == doctor_id:
                found = True
                break

        if found:
            # Destroy current doctor details frame
            self.doctor_details_frame.destroy()

            # Recreatting doctor update details frame
            self.doctor_update_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.doctor_update_frame.pack(expand=True)

            # Filling the existing details in entry fields
            id_label = tk.Label(self.doctor_update_frame, text="Doctor ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            id_label.grid(row=0, column=0, sticky="e", padx=10, pady=5)
            self.updated_doctor_id_entry = tk.Entry(self.doctor_update_frame)
            self.updated_doctor_id_entry.insert(0, current_doctor_id)
            self.updated_doctor_id_entry.config(state="disabled")
            self.updated_doctor_id_entry.grid(row=0, column=1, padx=10, pady=5)

            name_label = tk.Label(self.doctor_update_frame, text="Doctor Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            name_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
            self.updated_doctor_name_entry = tk.Entry(self.doctor_update_frame)
            self.updated_doctor_name_entry.insert(0, name)
            self.updated_doctor_name_entry.grid(row=1, column=1, padx=10, pady=5)

            address_label = tk.Label(self.doctor_update_frame, text="Doctor Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            address_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
            self.updated_doctor_address_entry = tk.Entry(self.doctor_update_frame)
            self.updated_doctor_address_entry.insert(0, address)
            self.updated_doctor_address_entry.grid(row=2, column=1, padx=10, pady=5)

            office_label = tk.Label(self.doctor_update_frame, text="Office Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            office_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
            self.updated_doctor_office_entry = tk.Entry(self.doctor_update_frame)
            self.updated_doctor_office_entry.insert(0, office_number)
            self.updated_doctor_office_entry.grid(row=3, column=1, padx=10, pady=5)

            contact_label = tk.Label(self.doctor_update_frame, text="Contact Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            contact_label.grid(row=4, column=0, sticky="e", padx=10, pady=5)
            self.updated_doctor_contact_entry = tk.Entry(self.doctor_update_frame)
            self.updated_doctor_contact_entry.insert(0, contact_number)
            self.updated_doctor_contact_entry.grid(row=4, column=1, padx=10, pady=5)

            # Submit button for update
            update_button = tk.Button(self.doctor_update_frame, text="Update", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_updated_doctor)
            update_button.grid(row=5, columnspan=2, padx=10, pady=(10, 20))
        else:
            messagebox.showerror("Error", "Doctor ID not found.")

    def submit_updated_doctor(self):
        # Getting updated doctor details from entry fields
        updated_doctor_id = self.updated_doctor_id_entry.get()
        updated_name = self.updated_doctor_name_entry.get()
        updated_address = self.updated_doctor_address_entry.get()
        updated_office_number = self.updated_doctor_office_entry.get()
        updated_contact_number = self.updated_doctor_contact_entry.get()

        # Validating if any field is empty
        if not all([updated_doctor_id, updated_name, updated_address, updated_office_number, updated_contact_number]):
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        # Updating doctor details in the file
        with open("doctor.txt", "r") as f:
            lines = f.readlines()

        with open("doctor.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract doctor ID
                current_doctor_id, *details = line.strip().split(",")
                if current_doctor_id == updated_doctor_id:
                    # writing the updated doctor details to the file
                    f.write(f"{updated_doctor_id},{updated_name},{updated_address},{updated_office_number},{updated_contact_number}\n")
                else:
                    # writing the existing doctor details back to the file
                    f.write(line)

        # Inform user about successful update
        messagebox.showinfo("Success", "Doctor details updated successfully.")

        self.doctor_update_frame.destroy()
        # Reset the screen to ask for the doctor ID again
        self.update_doctor()

    def update_nurse(self):
        self.functionality_label.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        # Destroy nurse details frame if it exists
        if hasattr(self, 'nurse_details_frame'):
            self.nurse_details_frame.destroy()

        if hasattr(self,'nurse_update_frame'):
            self.nurse_update_frame.destroy()
        
        if hasattr(self,'doctor_update_frame'):
            self.doctor_update_frame.destroy()

        # Recreatting nurse details frame
        self.nurse_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.nurse_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.nurse_details_frame, text="Update Nurse", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Nurse ID label and entry field
        id_label = tk.Label(self.nurse_details_frame, text="Nurse ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.nurse_id_entry = tk.Entry(self.nurse_details_frame)  # Using separate attribute for nurse ID entry
        self.nurse_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.nurse_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_update_nurse)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_update_nurse(self):
        # Getting nurse ID from entry field
        nurse_id = self.nurse_id_entry.get()

        # Validatting if the nurse ID is provided
        if not nurse_id:
            messagebox.showerror("Error", "Please enter Nurse ID.")
            return

        # Searching the nurse in the file
        with open("nurse.txt", "r") as f:
            lines = f.readlines()

        found = False
        for line in lines:
            # Splitting the line to extract nurse ID and details
            current_nurse_id, name, address, contact_number, ward_number = line.strip().split(",")
            if current_nurse_id == nurse_id:
                found = True
                break

        if found:
            # Destroy current nurse details frame
            self.nurse_details_frame.destroy()

            # Recreating nurse update details frame
            self.nurse_update_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.nurse_update_frame.pack(expand=True)

            # Filling the existing details in entry fields
            id_label = tk.Label(self.nurse_update_frame, text="Nurse ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            id_label.grid(row=0, column=0, sticky="e", padx=10, pady=5)
            self.updated_nurse_id_entry = tk.Entry(self.nurse_update_frame)
            self.updated_nurse_id_entry.insert(0, current_nurse_id)
            self.updated_nurse_id_entry.config(state="disabled")
            self.updated_nurse_id_entry.grid(row=0, column=1, padx=10, pady=5)

            name_label = tk.Label(self.nurse_update_frame, text="Nurse Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            name_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
            self.updated_nurse_name_entry = tk.Entry(self.nurse_update_frame)
            self.updated_nurse_name_entry.insert(0, name)
            self.updated_nurse_name_entry.grid(row=1, column=1, padx=10, pady=5)

            address_label = tk.Label(self.nurse_update_frame, text="Nurse Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            address_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
            self.updated_nurse_address_entry = tk.Entry(self.nurse_update_frame)
            self.updated_nurse_address_entry.insert(0, address)
            self.updated_nurse_address_entry.grid(row=2, column=1, padx=10, pady=5)

            contact_label = tk.Label(self.nurse_update_frame, text="Contact Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            contact_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
            self.updated_nurse_contact_entry = tk.Entry(self.nurse_update_frame)
            self.updated_nurse_contact_entry.insert(0, contact_number)
            self.updated_nurse_contact_entry.grid(row=3, column=1, padx=10, pady=5)

            ward_label = tk.Label(self.nurse_update_frame, text="Ward Number:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            ward_label.grid(row=4, column=0, sticky="e", padx=10, pady=5)
            self.updated_nurse_ward_entry = tk.Entry(self.nurse_update_frame)
            self.updated_nurse_ward_entry.insert(0, ward_number)
            self.updated_nurse_ward_entry.grid(row=4, column=1, padx=10, pady=5)

            # Submit button for update
            update_button = tk.Button(self.nurse_update_frame, text="Update", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_updated_nurse)
            update_button.grid(row=5, columnspan=2, padx=10, pady=(10, 20))
        else:
            messagebox.showerror("Error", "Nurse ID not found.")

    def submit_updated_nurse(self):
        # Getting updated nurse details from entry fields
        updated_nurse_id = self.updated_nurse_id_entry.get()
        updated_name = self.updated_nurse_name_entry.get()
        updated_address = self.updated_nurse_address_entry.get()
        updated_contact_number = self.updated_nurse_contact_entry.get()
        updated_ward_number = self.updated_nurse_ward_entry.get()

        # Validatting if any field is empty
        if not all([updated_nurse_id, updated_name, updated_address, updated_contact_number, updated_ward_number]):
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        # Updating nurse details in the file
        with open("nurse.txt", "r") as f:
            lines = f.readlines()

        with open("nurse.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract nurse ID
                current_nurse_id, *details = line.strip().split(",")
                if current_nurse_id == updated_nurse_id:
                    # Writing the updated nurse details to the file
                    f.write(f"{updated_nurse_id},{updated_name},{updated_address},{updated_contact_number},{updated_ward_number}\n")
                else:
                    # Writing the existing nurse details back to the file
                    f.write(line)

        # Informing user about successful update
        messagebox.showinfo("Success", "Nurse details updated successfully.")

        self.nurse_update_frame.destroy()
        # Reset the screen to ask for the nurse ID again
        self.update_nurse()

class StaffDashboard(tk.Toplevel):
    def __init__(self, root):
        try:
            super().__init__(root)
            self.title("Staff Dashboard")
            self.configure(background="navy")  # Setting background color to navy

            # Setting window size and position
            window_width = 1000
            window_height = 400
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()
            x_coordinate = (screen_width - window_width) / 2
            y_coordinate = (screen_height - window_height) / 2
            self.geometry("%dx%d+%d+%d" % (window_width, window_height, x_coordinate, y_coordinate))

            # Dashboard frame
            dashboard_frame = tk.Frame(self, bg="navy")
            dashboard_frame.pack(fill=tk.BOTH)

            # Functionality display frame
            self.functionality_frame = tk.Frame(self, bg="navy", height=300)
            self.functionality_frame.pack(expand=True, fill=tk.BOTH)

            # Functionality display label
            self.functionality_label = tk.Label(self.functionality_frame, text="Select a functionality", bg="white")
            self.functionality_label.pack(expand=True, pady=20)

            # Add Patient button
            self.add_patient_button = tk.Button(dashboard_frame, text="Add Patient", width=10, command=self.add_patient)
            self.add_patient_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Delete Patient button
            self.delete_patient_button = tk.Button(dashboard_frame, text="Delete Patient", width=11, command=self.delete_patient)
            self.delete_patient_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Update Patient button
            self.update_patient_button = tk.Button(dashboard_frame, text="Update Patient", width=12, command=self.update_patient)
            self.update_patient_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Add Appointment button
            self.add_appointment_button = tk.Button(dashboard_frame, text="Add Appointment", width=15, command=self.add_appointment)
            self.add_appointment_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Remove Appointment button
            self.remove_appointment_button = tk.Button(dashboard_frame, text="Remove Appointment", width=17, command=self.remove_appointment)
            self.remove_appointment_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Prescribe Medicine button
            self.prescribe_medicine_button = tk.Button(dashboard_frame, text="Prescribe Medicine", width=16, command=self.prescribe_medicine)
            self.prescribe_medicine_button.pack(side=tk.LEFT, padx=12, pady=12)

            # View All Patients button
            self.view_all_patients_button = tk.Button(dashboard_frame, text="View All Patients", width=17, command=self.view_all_patients)
            self.view_all_patients_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Logout button
            self.logout_button = tk.Button(dashboard_frame, text="Logout", width=15, command=self.show_login_window)
            self.logout_button.pack(side=tk.LEFT, padx=12, pady=12)

            self.patient_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.patient_details_frame.pack(expand=True)

            self.appointment_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.appointment_details_frame.pack(expand=True)

            self.temp = None

            # Binding the closing event to show login window
            self.protocol("WM_DELETE_WINDOW", self.show_login_window)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def show_login_window(self):
        try:
            # Destroy staff dashboard window
            self.destroy()
            password_entry.delete(0,tk.END)

            # Recreating login window
            root.deiconify()  # Restore visibility of the login window
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def view_all_patients(self):
        try:
            self.functionality_label.destroy()

             # Destroy appointment details frame if it exists
            if hasattr(self, 'appointment_details_frame'):
                self.appointment_details_frame.destroy()

            # Destroy patient details frame if it exists
            if hasattr(self, 'patient_details_frame'):
                self.patient_details_frame.destroy()
            
            # Destroy medicine details frame if it exists
            if hasattr(self, 'prescribe_medicine_details_frame'):
                self.prescribe_medicine_details_frame.destroy()
            
            # Destroy medicine details frame if it exists
            if hasattr(self, 'prescribe_medicine_frame'):
                self.prescribe_medicine_frame.destroy()

            # Destroy patient update frame if it exists
            if hasattr(self, 'patient_update_frame'):
                self.patient_update_frame.destroy()

            # Recreating patient details frame
            self.patient_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.patient_details_frame.pack(expand=True)

            # Heading label
            heading_label = tk.Label(self.patient_details_frame, text="All Patients", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
            heading_label.grid(row=0, columnspan=2, pady=(10, 5))

            # Creating a scrollable canvas
            canvas = tk.Canvas(self.patient_details_frame, bg="white")
            canvas.grid(row=1, column=0, sticky="nsew")

            # Adding a vertical scrollbar
            scrollbar = tk.Scrollbar(self.patient_details_frame, orient="vertical", command=canvas.yview)
            scrollbar.grid(row=1, column=1, sticky="ns")
            canvas.configure(yscrollcommand=scrollbar.set)

            # Frame for patient labels
            patient_frame = tk.Frame(canvas, bg="white")
            canvas.create_window((0, 0), window=patient_frame, anchor="nw")

            # Reading and displaying all patients from patient.txt
            with open("patient.txt", "r") as file:
                patients = file.readlines()
                for index, patient in enumerate(patients, start=1):
                    patient_data = patient.strip().split(",")
                    # Extracting patient details
                    patient_id = patient_data[0].strip()
                    patient_name = patient_data[1].strip()
                    patient_label_text = "ID: " + str(patient_id) + ", Name: " + str(patient_name)
                    patient_label = tk.Label(patient_frame, text=patient_label_text, bg="white", fg="black", font=("Helvetica", 10))
                    patient_label.grid(row=index, columnspan=5, pady=5)

            # Updating scroll region
            patient_frame.update_idletasks()
            canvas.config(scrollregion=canvas.bbox("all"))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")


    def add_patient(self):
        self.functionality_label.destroy()

         # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_details_frame'):
            self.prescribe_medicine_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_frame'):
            self.prescribe_medicine_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating patient details frame
        self.patient_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.patient_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.patient_details_frame, text="Enter Patient Details", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Patient details labels and entry fields
        id_label = tk.Label(self.patient_details_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.patient_id_entry = tk.Entry(self.patient_details_frame)  # Using separate attribute for patient ID entry
        self.patient_id_entry.grid(row=1, column=1, padx=10, pady=5)

        name_label = tk.Label(self.patient_details_frame, text="Patient Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        name_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
        self.patient_name_entry = tk.Entry(self.patient_details_frame)  # Using separate attribute for patient name entry
        self.patient_name_entry.grid(row=2, column=1, padx=10, pady=5)

        address_label = tk.Label(self.patient_details_frame, text="Patient Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        address_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
        self.patient_address_entry = tk.Entry(self.patient_details_frame)  # Using separate attribute for patient address entry
        self.patient_address_entry.grid(row=3, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.patient_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_patient)
        submit_button.grid(row=4, columnspan=2, padx=10, pady=(10, 20))

    def submit_patient(self):
        # Getting patient details from entry fields
        patient_id = self.patient_id_entry.get()
        name = self.patient_name_entry.get()
        address = self.patient_address_entry.get()

        # Validating if any field is empty
        if not all([patient_id, name, address]):
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        # Saving patient details to file
        with open("patient.txt", "a") as f:
            f.write(f"{patient_id},{name},{address}\n")

        # Inform user about successful addition
        messagebox.showinfo("Success", "Patient added successfully.")

        # Clearing entry fields
        self.clear_patient_fields()

    def clear_patient_fields(self):
        if hasattr(self, 'patient_id_entry'):
            self.patient_id_entry.delete(0, tk.END)
        if hasattr(self, 'patient_name_entry'):
            self.patient_name_entry.delete(0, tk.END)
        if hasattr(self, 'patient_address_entry'):
            self.patient_address_entry.delete(0, tk.END)

    def delete_patient(self):
        self.functionality_label.destroy()

        # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_details_frame'):
            self.prescribe_medicine_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_frame'):
            self.prescribe_medicine_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating patient details frame
        self.patient_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.patient_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.patient_details_frame, text="Delete Patient", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Patient ID label and entry field
        id_label = tk.Label(self.patient_details_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.patient_id_entry = tk.Entry(self.patient_details_frame)  # Using separate attribute for patient ID entry
        self.patient_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.patient_details_frame, text="Delete", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_delete_patient)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_delete_patient(self):
        # Getting patient ID from entry field
        patient_id = self.patient_id_entry.get()

        # Validating if the patient ID is provided
        if not patient_id:
            messagebox.showerror("Error", "Please enter Patient ID.")
            return

        # Searching for the patient in the file
        with open("patient.txt", "r") as f:
            lines = f.readlines()

        found = False
        with open("patient.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract patient ID
                current_patient_id, *details = line.strip().split(",")
                if current_patient_id != patient_id:
                    # Writing the patient details back to the file if ID doesn't match
                    f.write(line)
                else:
                    found = True

        if found:
            messagebox.showinfo("Success", "Patient deleted successfully.")
            self.clear_delete_patient_fields()
        else:
            messagebox.showerror("Error", "Patient ID not found.")

    def clear_delete_patient_fields(self):
        if hasattr(self, 'patient_id_entry'):
            self.patient_id_entry.delete(0, tk.END)

    def update_patient(self):
        self.functionality_label.destroy()

        # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_details_frame'):
            self.prescribe_medicine_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_frame'):
            self.prescribe_medicine_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()
        
        # Recreating patient details frame
        self.patient_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.patient_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.patient_details_frame, text="Update Patient", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Patient ID label and entry field
        id_label = tk.Label(self.patient_details_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.patient_id_entry = tk.Entry(self.patient_details_frame)  # Use separate attribute for patient ID entry
        self.patient_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.patient_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_update_patient)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_update_patient(self):
        # Getting patient ID from entry field
        patient_id = self.patient_id_entry.get()

        # Validating if the patient ID is provided
        if not patient_id:
            messagebox.showerror("Error", "Please enter Patient ID.")
            return

        # Search for the patient in the file
        with open("patient.txt", "r") as f:
            lines = f.readlines()

        found = False
        for line in lines:
            # Splitting the line to extract patient ID and details
            current_patient_id, *details = line.strip().split(",")
            if current_patient_id == patient_id:
                found = True
                break

        if found:
            # Destroy current patient details frame
            self.patient_details_frame.destroy()

            # Recreating patient update details frame
            self.patient_update_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.patient_update_frame.pack(expand=True)

            # Filling the existing details in entry fields
            id_label = tk.Label(self.patient_update_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            id_label.grid(row=0, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_id_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_id_entry.insert(0, current_patient_id)
            self.updated_patient_id_entry.config(state="disabled")
            self.updated_patient_id_entry.grid(row=0, column=1, padx=10, pady=5)

            name_label = tk.Label(self.patient_update_frame, text="Patient Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            name_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_name_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_name_entry.insert(0, details[0] if details else "")
            self.updated_patient_name_entry.grid(row=1, column=1, padx=10, pady=5)

            address_label = tk.Label(self.patient_update_frame, text="Patient Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            address_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_address_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_address_entry.insert(0, details[1] if details else "")
            self.updated_patient_address_entry.grid(row=2, column=1, padx=10, pady=5)

            medicine_label = tk.Label(self.patient_update_frame, text="Prescribed Medicine:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            medicine_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_medicine_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_medicine_entry.insert(0, details[2] if len(details) >= 3 else "")
            self.updated_patient_medicine_entry.grid(row=3, column=1, padx=10, pady=5)

            # Submit button for update
            update_button = tk.Button(self.patient_update_frame, text="Update", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_updated_patient)
            update_button.grid(row=4, columnspan=2, padx=10, pady=(10, 20))
        else:
            messagebox.showerror("Error", "Patient ID not found.")

    def submit_updated_patient(self):
        # Getting updated patient details from entry fields
        updated_patient_id = self.updated_patient_id_entry.get()
        updated_name = self.updated_patient_name_entry.get()
        updated_address = self.updated_patient_address_entry.get()
        updated_medicine = self.updated_patient_medicine_entry.get()

        # Validating if any field is empty
        if not all([updated_patient_id, updated_name, updated_address]):
            messagebox.showerror("Error", "Please fill in all the required fields.")
            return

        # updating patient details in the file
        with open("patient.txt", "r") as f:
            lines = f.readlines()

        with open("patient.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract patient ID
                current_patient_id, *details = line.strip().split(",")
                if current_patient_id == updated_patient_id:
                    # Writing the updated patient details to the file
                    f.write(f"{updated_patient_id},{updated_name},{updated_address},{updated_medicine}\n")
                else:
                    # Writing the existing patient details back to the file
                    f.write(line)

        # Inform user about successful update
        messagebox.showinfo("Success", "Patient details updated successfully.")

        self.patient_update_frame.destroy()
        # Reset the screen to ask for the patient ID again
        self.update_patient()

    def add_appointment(self):
        self.functionality_label.destroy()

        # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_details_frame'):
            self.prescribe_medicine_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_frame'):
            self.prescribe_medicine_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating appointment details frame
        self.appointment_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.appointment_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.appointment_details_frame, text="Enter Appointment Details", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Appointment details labels and entry fields
        id_label = tk.Label(self.appointment_details_frame, text="Appointment ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.appointment_id_entry = tk.Entry(self.appointment_details_frame)  # Using separate attribute for appointment ID entry
        self.appointment_id_entry.grid(row=1, column=1, padx=10, pady=5)

        date_label = tk.Label(self.appointment_details_frame, text="Date:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        date_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
        self.date_entry = tk.Entry(self.appointment_details_frame)  # Using separate attribute for date entry
        self.date_entry.grid(row=2, column=1, padx=10, pady=5)

        patient_label = tk.Label(self.appointment_details_frame, text="Description:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        patient_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
        self.patient_name_entry = tk.Entry(self.appointment_details_frame)  # Using separate attribute for patient name entry
        self.patient_name_entry.grid(row=3, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.appointment_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_appointment)
        submit_button.grid(row=4, columnspan=2, padx=10, pady=(10, 20))

    def submit_appointment(self):
        # Get appointment details from entry fields
        appointment_id = self.appointment_id_entry.get()
        date = self.date_entry.get()
        patient_name = self.patient_name_entry.get()

        # Validate if any field is empty
        if not all([appointment_id, date, patient_name]):
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        # Save appointment details to file
        with open("appointment.txt", "a") as f:
            f.write(f"{appointment_id},{date},{patient_name}\n")

        # Inform user about successful addition
        messagebox.showinfo("Success", "Appointment added successfully.")

        # Clear entry fields
        self.clear_appointment_fields()

    def clear_appointment_fields(self):
        if hasattr(self, 'appointment_id_entry'):
            self.appointment_id_entry.delete(0, tk.END)
        if hasattr(self, 'date_entry'):
            self.date_entry.delete(0, tk.END)
        if hasattr(self, 'patient_name_entry'):
            self.patient_name_entry.delete(0, tk.END)

    def remove_appointment(self):
        self.functionality_label.destroy()

         # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_details_frame'):
            self.prescribe_medicine_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_frame'):
            self.prescribe_medicine_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating appointment details frame
        self.appointment_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.appointment_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.appointment_details_frame, text="Remove Appointment", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Appointment ID label and entry field
        id_label = tk.Label(self.appointment_details_frame, text="Appointment ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.appointment_id_entry = tk.Entry(self.appointment_details_frame)  # Using separate attribute for appointment ID entry
        self.appointment_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.appointment_details_frame, text="Remove", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_remove_appointment)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_remove_appointment(self):
        # Getting appointment ID from entry field
        appointment_id = self.appointment_id_entry.get()

        # Validating if the appointment ID is provided
        if not appointment_id:
            messagebox.showerror("Error", "Please enter Appointment ID.")
            return

        # Search for the appointment in the file
        with open("appointment.txt", "r") as f:
            lines = f.readlines()

        found = False
        with open("appointment.txt", "w") as f:
            for line in lines:
                # Splitting the line to extract appointment ID
                current_appointment_id, *details = line.strip().split(",")
                if current_appointment_id != appointment_id:
                    # Writing the appointment details back to the file if ID doesn't match
                    f.write(line)
                else:
                    found = True

        if found:
            messagebox.showinfo("Success", "Appointment removed successfully.")
            self.clear_remove_appointment_fields()
        else:
            messagebox.showerror("Error", "Appointment ID not found.")

    def clear_remove_appointment_fields(self):
        if hasattr(self, 'appointment_id_entry'):
            self.appointment_id_entry.delete(0, tk.END)

    def prescribe_medicine(self):
        self.functionality_label.destroy()

         # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_details_frame'):
            self.prescribe_medicine_details_frame.destroy()
        
        # Destroy medicine details frame if it exists
        if hasattr(self, 'prescribe_medicine_frame'):
            self.prescribe_medicine_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating prescribe medicine details frame
        self.prescribe_medicine_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.prescribe_medicine_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.prescribe_medicine_frame, text="Prescribe Medicine", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Patient ID label and entry field
        id_label = tk.Label(self.prescribe_medicine_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.patient_id_entry = tk.Entry(self.prescribe_medicine_frame)  # Using separate attribute for patient ID entry
        self.patient_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.prescribe_medicine_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.submit_prescribe_medicine)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def submit_prescribe_medicine(self):
        # Getting patient ID from entry field
        patient_id = self.patient_id_entry.get()
        self.temp = patient_id

        # Validating if the patient ID is provided
        if not patient_id:
            messagebox.showerror("Error", "Please enter Patient ID.")
            return

        # Searching for the patient in the file
        with open("patient.txt", "r") as f:
            lines = f.readlines()

        found = False
        for line in lines:
            # Splitting the line to extract patient ID
            current_patient_id, *details = line.strip().split(",")
            if current_patient_id == patient_id:
                found = True
                break

        if found:
            # Destroy current prescribe medicine frame
            self.prescribe_medicine_frame.destroy()

            # Recreating prescribe medicine details frame
            self.prescribe_medicine_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.prescribe_medicine_details_frame.pack(expand=True)

            # Medicine details labels and entry fields
            medicine_label = tk.Label(self.prescribe_medicine_details_frame, text="Prescribed Medicine:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            medicine_label.grid(row=0, column=0, sticky="e", padx=10, pady=5)
            self.medicine_entry = tk.Entry(self.prescribe_medicine_details_frame)  # Using separate attribute for medicine entry
            self.medicine_entry.grid(row=0, column=1, padx=10, pady=5)

            # Submit button for prescribing medicine
            prescribe_button = tk.Button(self.prescribe_medicine_details_frame, text="Prescribe", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.prescribe_medicine_action)
            prescribe_button.grid(row=1, columnspan=2, padx=10, pady=(10, 20))
        else:
            messagebox.showerror("Error", "Patient ID not found.")

    def prescribe_medicine_action(self):
        # Getting medicine details from entry field
        medicine = self.medicine_entry.get()

        # Validating if the medicine is provided
        if not medicine:
            messagebox.showerror("Error", "Please enter Prescribed Medicine.")
            return

        # Appending prescribed medicine to the patient's row in the file
        with open("patient.txt", "r+") as f:
            lines = f.readlines()
            f.seek(0)
            found = False
            for line in lines:
                current_patient_id, *details = line.strip().split(",")
                if current_patient_id == self.temp:
                    found = True
                    f.write(f"{line.strip()},{medicine}\n")
                else:
                    f.write(line)
            f.truncate()

        if found:
            # Informing user about successful prescription
            messagebox.showinfo("Success", "Medicine prescribed successfully.")
        else:
            messagebox.showerror("Error", "Patient ID not found.")

        self.prescribe_medicine_details_frame.destroy()
        self.prescribe_medicine()

class PatientDashboard(tk.Toplevel):
    def __init__(self, root):
        try:
            super().__init__(root)
            self.title("Patient Dashboard")
            self.configure(background="navy")  # Setting background color to navy

            # Setting window size and position
            window_width = 550
            window_height = 380
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()
            x_coordinate = (screen_width - window_width) / 2
            y_coordinate = (screen_height - window_height) / 2
            self.geometry("%dx%d+%d+%d" % (window_width, window_height, x_coordinate, y_coordinate))

            # Dashboard frame
            dashboard_frame = tk.Frame(self, bg="navy")
            dashboard_frame.pack(fill=tk.BOTH)

            # Functionality display frame
            self.functionality_frame = tk.Frame(self, bg="navy", height=300)
            self.functionality_frame.pack(expand=True, fill=tk.BOTH)

            # Functionality display label
            self.functionality_label = tk.Label(self.functionality_frame, text="Select a functionality", bg="white")
            self.functionality_label.pack(expand=True, pady=20)

            # View Appointment button
            self.view_appointment_button = tk.Button(dashboard_frame, text="View Appointments", width=16, command=self.view_appointments)
            self.view_appointment_button.pack(side=tk.LEFT, padx=12, pady=12)

            # View Prescribed Medicine button
            self.view_medicine_button = tk.Button(dashboard_frame, text="View Prescribed Medicine", width=20, command=self.view_prescribed_medicine)
            self.view_medicine_button.pack(side=tk.LEFT, padx=12, pady=12)

            # View All Doctors button
            self.view_all_doctors_button = tk.Button(dashboard_frame, text="View All Doctors", width=16, command=self.view_all_doctors)
            self.view_all_doctors_button.pack(side=tk.LEFT, padx=12, pady=12)

            # Logout button
            self.logout_button = tk.Button(dashboard_frame, text="Logout", width=13, command=self.show_login_window)
            self.logout_button.pack(side=tk.LEFT, padx=12, pady=12)

            self.appointment_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.appointment_details_frame.pack(expand=True)

            self.medicine_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.medicine_details_frame.pack(expand=True)

            # Bind the closing event to show login window
            self.protocol("WM_DELETE_WINDOW", self.show_login_window)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def show_login_window(self):
        try:
            # Destroy patient dashboard window
            self.destroy()

            # Recreating login window
            root.deiconify()  # Restore visibility of the login window
            password_entry.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def view_all_doctors(self):
        try:
            self.functionality_label.destroy()

            # Destroy doctor details frame if it exists
            if hasattr(self, 'doctor_details_frame'):
                self.doctor_details_frame.destroy()

            # Destroy appointment details frame if it exists
            if hasattr(self, 'appointment_details_frame'):
                self.appointment_details_frame.destroy()

            # Destroy patient details frame if it exists
            if hasattr(self, 'patient_details_frame'):
                self.patient_details_frame.destroy()

            # Destroy appointment view frame if it exists
            if hasattr(self, 'appointment_view_frame'):
                self.appointment_view_frame.destroy()

            # Destroy patient update frame if it exists
            if hasattr(self, 'patient_update_frame'):
                self.patient_update_frame.destroy()

            # Recreating doctor details frame
            self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.doctor_details_frame.pack(expand=True)

            # Heading label
            heading_label = tk.Label(self.doctor_details_frame, text="All Doctors", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
            heading_label.grid(row=0, columnspan=2, pady=(10, 5))

            # Creating a scrollable canvas
            canvas = tk.Canvas(self.doctor_details_frame, bg="white")
            canvas.grid(row=1, column=0, sticky="nsew")

            # Adding a vertical scrollbar
            scrollbar = tk.Scrollbar(self.doctor_details_frame, orient="vertical", command=canvas.yview)
            scrollbar.grid(row=1, column=1, sticky="ns")
            canvas.configure(yscrollcommand=scrollbar.set)

            # Frame for doctor labels
            doctor_frame = tk.Frame(canvas, bg="white")
            canvas.create_window((0, 0), window=doctor_frame, anchor="nw")

            # Reading and displaying all doctors from doctor.txt
            with open("doctor.txt", "r") as file:
                doctors = file.readlines()
                for index, doctor in enumerate(doctors, start=1):
                    doctor_data = doctor.strip().split(",")
                    # Extracting doctor details
                    doctor_id = doctor_data[0].strip()
                    doctor_name = doctor_data[1].strip()
                    doctor_contact = doctor_data[4].strip()
                    doctor_label_text = "ID: " + str(doctor_id) + ", Name: " + str(doctor_name) + ", Contact: " + str(doctor_contact)
                    doctor_label = tk.Label(doctor_frame, text=doctor_label_text, bg="white", fg="black", font=("Helvetica", 10))
                    doctor_label.grid(row=index, columnspan=5, pady=5)

            # Updating scroll region
            doctor_frame.update_idletasks()
            canvas.config(scrollregion=canvas.bbox("all"))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")


    def view_appointments(self):
        self.functionality_label.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()

        # Destroy appointment view frame if it exists
        if hasattr(self, 'appointment_view_frame'):
            self.appointment_view_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating appointment details frame
        self.appointment_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.appointment_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.appointment_details_frame, text="View Appointment", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # appointment ID label and entry field
        id_label = tk.Label(self.appointment_details_frame, text="Appointment ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.appointment_id_entry = tk.Entry(self.appointment_details_frame)  # Using separate attribute for appointment ID entry
        self.appointment_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.appointment_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.show_appointment_details)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def show_appointment_details(self):
        # Getting appointment ID from entry field
        appointment_id = self.appointment_id_entry.get()

        # Validating if the appointment ID is provided
        if not appointment_id:
            messagebox.showerror("Error", "Please enter Appointment ID.")
            return

        # Searching the appointment in the file
        with open("appointment.txt", "r") as f:
            lines = f.readlines()

        found = False
        for line in lines:
            # Splitting the line to extract appointment ID and details
            current_appointment_id, *details = line.strip().split(",")
            if current_appointment_id == appointment_id:
                found = True
                break

        if found:
            # Destroy current appointment details frame
            self.appointment_details_frame.destroy()

            # Recreating appointment update details frame
            self.appointment_view_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.appointment_view_frame.pack(expand=True)

            # Fill in the existing details in entry fields
            id_label = tk.Label(self.appointment_view_frame, text="Appointment ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            id_label.grid(row=0, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_id_entry = tk.Entry(self.appointment_view_frame)
            self.updated_patient_id_entry.insert(0, appointment_id)
            self.updated_patient_id_entry.config(state="disabled")
            self.updated_patient_id_entry.grid(row=0, column=1, padx=10, pady=5)

            name_label = tk.Label(self.appointment_view_frame, text="Date:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            name_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_name_entry = tk.Entry(self.appointment_view_frame)
            self.updated_patient_name_entry.insert(0, details[0] if details else "")
            self.updated_patient_name_entry.config(state="disabled")
            self.updated_patient_name_entry.grid(row=1, column=1, padx=10, pady=5)

            address_label = tk.Label(self.appointment_view_frame, text="Patient Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            address_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_address_entry = tk.Entry(self.appointment_view_frame)
            self.updated_patient_address_entry.insert(0, details[1] if details else "")
            self.updated_patient_address_entry.config(state="disabled")
            self.updated_patient_address_entry.grid(row=2, column=1, padx=10, pady=5)

            # Go back button
            go_back_button = tk.Button(self.appointment_view_frame, text="Go Back", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.view_appointments)
            go_back_button.grid(row=4, columnspan=2, padx=10, pady=(10, 20))
        else:
            messagebox.showerror("Error", "Appointment ID not found.")

    def view_prescribed_medicine(self):
        self.functionality_label.destroy()

        # Destroy doctor details frame if it exists
        if hasattr(self, 'doctor_details_frame'):
            self.doctor_details_frame.destroy()

        # Destroy appointment details frame if it exists
        if hasattr(self, 'appointment_details_frame'):
            self.appointment_details_frame.destroy()

        # Destroy patient details frame if it exists
        if hasattr(self, 'patient_details_frame'):
            self.patient_details_frame.destroy()

        # Destroy appointment view frame if it exists
        if hasattr(self, 'appointment_view_frame'):
            self.appointment_view_frame.destroy()

        # Destroy patient update frame if it exists
        if hasattr(self, 'patient_update_frame'):
            self.patient_update_frame.destroy()

        # Recreating patient details frame
        self.patient_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
        self.patient_details_frame.pack(expand=True)

        # Heading label
        heading_label = tk.Label(self.patient_details_frame, text="View Prescribed Medicine", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
        heading_label.grid(row=0, columnspan=2, pady=(10, 5))

        # Patient ID label and entry field
        id_label = tk.Label(self.patient_details_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
        id_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.patient_id_entry = tk.Entry(self.patient_details_frame)  # Using separate attribute for patient ID entry
        self.patient_id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Submit button
        submit_button = tk.Button(self.patient_details_frame, text="Submit", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.show_patient_details)
        submit_button.grid(row=2, columnspan=2, padx=10, pady=(10, 20))

    def show_patient_details(self):
        # Getting patient ID from entry field
        patient_id = self.patient_id_entry.get()

        # Validating if the patient ID is provided
        if not patient_id:
            messagebox.showerror("Error", "Please enter Patient ID.")
            return

        # Search for the patient in the file
        with open("patient.txt", "r") as f:
            lines = f.readlines()

        found = False
        for line in lines:
            # Splitting the line to extract patient ID and details
            current_patient_id, *details = line.strip().split(",")
            if current_patient_id == patient_id:
                found = True
                break

        if found:
            # Destroy current patient details frame
            self.patient_details_frame.destroy()

            # Recreating patient update details frame
            self.patient_update_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.patient_update_frame.pack(expand=True)

            # Fill in the existing details in entry fields
            id_label = tk.Label(self.patient_update_frame, text="Patient ID:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            id_label.grid(row=0, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_id_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_id_entry.insert(0, current_patient_id)
            self.updated_patient_id_entry.config(state="disabled")
            self.updated_patient_id_entry.grid(row=0, column=1, padx=10, pady=5)

            name_label = tk.Label(self.patient_update_frame, text="Patient Name:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            name_label.grid(row=1, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_name_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_name_entry.insert(0, details[0] if details else "")
            self.updated_patient_name_entry.config(state="disabled")
            self.updated_patient_name_entry.grid(row=1, column=1, padx=10, pady=5)

            address_label = tk.Label(self.patient_update_frame, text="Patient Address:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            address_label.grid(row=2, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_address_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_address_entry.insert(0, details[1] if details else "")
            self.updated_patient_address_entry.config(state="disabled")
            self.updated_patient_address_entry.grid(row=2, column=1, padx=10, pady=5)

            medicine_label = tk.Label(self.patient_update_frame, text="Prescribed Medicine:", bg="navy", fg="white", font=("Helvetica", 12, "bold"))
            medicine_label.grid(row=3, column=0, sticky="e", padx=10, pady=5)
            self.updated_patient_medicine_entry = tk.Entry(self.patient_update_frame)
            self.updated_patient_medicine_entry.insert(0, details[2] if len(details) >= 3 else "")
            self.updated_patient_medicine_entry.config(state="disabled")
            self.updated_patient_medicine_entry.grid(row=3, column=1, padx=10, pady=5)

            # Go back button
            go_back_button = tk.Button(self.patient_update_frame, text="Go Back", width=14, bg="white", fg="black", font=("Helvetica", 12, "bold"), command=self.view_prescribed_medicine)
            go_back_button.grid(row=4, columnspan=2, padx=10, pady=(10, 20))
        else:
            messagebox.showerror("Error", "Patient ID not found.")

# Creating main window
root = tk.Tk()
root.title("Hospital Management System Login Page")

# Setting window size and position
window_width = 500
window_height = 350
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_coordinate = (screen_width - window_width) / 2
y_coordinate = (screen_height - window_height) / 2
root.geometry("%dx%d+%d+%d" % (window_width, window_height, x_coordinate, y_coordinate))

# Setting background color to navy blue
root.config(bg="navy")

# Login frame with white background
login_frame = tk.Frame(root, bg="white", padx=40, pady=30)
login_frame.pack(pady=50)

# Main title label
title_label = tk.Label(login_frame, text="Hospital Management System Login Page", font=("Helvetica", 14), bg="white")
title_label.grid(row=0, columnspan=2, pady=(0, 20))

# Username label and entry
username_label = tk.Label(login_frame, text="Username:", bg="white")
username_label.grid(row=1, column=0, sticky="e")
username_entry = tk.Entry(login_frame)
username_entry.grid(row=1, column=1)

# Password label and entry
password_label = tk.Label(login_frame, text="Password:", bg="white")
password_label.grid(row=2, column=0, sticky="e")
password_entry = tk.Entry(login_frame, show="*")
password_entry.grid(row=2, column=1)

# Role label and dropdown
role_label = tk.Label(login_frame, text="Role:", bg="white")
role_label.grid(row=3, column=0, sticky="e")
role_var = tk.StringVar()
role_dropdown = tk.OptionMenu(login_frame, role_var, "Administrator", "Staff", "Patient")
role_dropdown.grid(row=3, column=1)

# Login button
login_button = tk.Button(login_frame, text="Login", command=login)
login_button.grid(row=4, columnspan=2, pady=(20, 0))

# Call update_username function whenever role is changed
role_var.trace("w", update_username)

root.mainloop()


