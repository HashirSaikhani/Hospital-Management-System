def view_all_doctors(self):
        try:
            self.functionality_label.destroy()

            # Destroy nurse details frame if it exists
            if hasattr(self, 'nurse_details_frame'):
                self.nurse_details_frame.destroy()

            # Destroy doctor details frame if it exists
            if hasattr(self, 'doctor_details_frame'):
                self.doctor_details_frame.destroy()
            
            if hasattr(self,'nurse_update_frame'):
                self.nurse_update_frame.destroy()
            
            if hasattr(self,'doctor_update_frame'):
                self.doctor_update_frame.destroy()

            # Recreating doctor details frame
            self.doctor_details_frame = tk.Frame(self.functionality_frame, bg="navy", padx=20, pady=10)
            self.doctor_details_frame.pack(expand=True)

            # Heading label
            heading_label = tk.Label(self.doctor_details_frame, text="All Doctors", bg="navy", fg="white", font=("Helvetica", 14, "bold"))
            heading_label.grid(row=0, columnspan=2, pady=(10, 5))

           # Creating a scrollable canvas
            canvas = tk.Canvas(self.doctor_details_frame, bg="white")
            canvas.grid(row=1, column=0, sticky="nsew")

            # Adding a vertical scrollbar
            scrollbar = tk.Scrollbar(self.doctor_details_frame, orient="vertical", command=canvas.yview)
            scrollbar.grid(row=1, column=1, sticky="ns")
            canvas.configure(yscrollcommand=scrollbar.set)

            # Frame for doctor labels
            doctor_frame = tk.Frame(canvas, bg="white")
            canvas.create_window((0, 0), window=doctor_frame, anchor="nw")

            # Reading and displaying all doctors from doctor.txt
            with open("doctor.txt", "r") as file:
                doctors = file.readlines()
                for index, doctor in enumerate(doctors, start=1):
                    doctor_data = doctor.strip().split(",")
                    # Extracting doctor details
                    doctor_id = doctor_data[0]
                    doctor_name = doctor_data[1]
                    doctor_contact = doctor_data[4]
                    # Creating label text with doctor details
                    doctor_label_text = f"ID: {doctor_id}, Name: {doctor_name}, Contact: {doctor_contact}"
                    doctor_label = tk.Label(doctor_frame, text=doctor_label_text, bg="white", fg="black", font=("Helvetica", 10))
                    doctor_label.grid(row=index, columnspan=2, pady=5)

            # Update scroll region to make scrollbar work
            doctor_frame.update_idletasks()
            canvas.config(scrollregion=canvas.bbox("all"))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")